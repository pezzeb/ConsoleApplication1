#include <SFML\Graphics.hpp>
#include <iostream>
#include <vector>
#include "Ball.h"
#include "Block.h"
#include "Gameboard.h"

int main() {

std::cout << "Main Program Start\n";
sf::RenderWindow window(sf::VideoMode(1400, 750), "SFML TUTORIAL", sf::Style::Close | sf::Style::Resize);

Gameboard Game;
Game.resetgameboard(window);

while (window.isOpen())
	{
		sf::Event evnt;
		while (window.pollEvent(evnt)) 
		{
			if (evnt.type == evnt.Closed)
			{
				window.close();
			}
		}


		if(Game.getgetstate() and not(Game.isendgame())){

			int v2 = rand() % 100 + 1;
			if (v2 < 30) {
				Game.setbarposition(Game.getoffsetboard() + 0.0);
			}
			else if (v2 < 63) {
				Game.setbarposition(Game.getoffsetboard() + 245);
			}
			else {
				Game.setbarposition(Game.getoffsetboard() + 490);
			}

			//Manual input
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A))
			{
				//Game.movebar(-1.0);
				Game.setbarposition(Game.getoffsetboard() + 0.0);
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S))
			{
				//Game.movebar(+1.0);getwidthofboard
				Game.setbarposition(Game.getoffsetboard() + 245);
			}
			if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D))
			{
				//Game.movebar(+1.0);
				Game.setbarposition(Game.getoffsetboard() + 490);
			}

			Game.drawboard(window);
			//window.draw(Game.scoretext);
			//sf::VertexArray lines(sf::LinesStrip, 2);
			//lines[0].position = sf::Vector2f(100, 100);
			//lines[0].color = sf::Color::Red;
			//lines[1].position = sf::Vector2f(200, 50);
			//lines[1].color = sf::Color::Red;

			//window.draw(lines);

			Game.steptime();
		
			//window.clear();
			//window.draw(lines);
			//window.display();

			/*rectangles.erase(rectangles.begin()+2);*/

			//window.draw(rectangles[0]);
			//window.draw(rectangles[1]);
		}
		else
		{
			Game.drawboard(window);
		}
	}

return 0;
}

//void printvector(std::vector<sf::RectangleShape> blocks, sf::RenderWindow& window) {
//
//	for (std::vector<sf::RectangleShape>::iterator it = blocks.begin(); it != blocks.end(); ++it) {
//		window.draw(*it);
//	}
//	window.display();
//}
//
//int main() {
//
//	sf::RenderWindow window(sf::VideoMode(1010, 710), "SFML TUTORIAL", sf::Style::Close | sf::Style::Resize);
//
//	sf::RectangleShape bounds(sf::Vector2f(1000, 700));
//	bounds.setOutlineColor(sf::Color::Black);
//	bounds.setOutlineThickness(5.0f);
//
//	sf::RectangleShape playerbar(sf::Vector2f(100, 8));
//	playerbar.setOutlineColor(sf::Color::Black);
//	playerbar.setFillColor(sf::Color::Black);
//	playerbar.setPosition(690.0f, 670.0f);
//
//	sf::RectangleShape player(sf::Vector2f(100, 100));
//	player.setFillColor(sf::Color::Red);
//	player.setOrigin(50.0f, 50.0f);
//	sf::Texture playerTexture;
//	playerTexture.loadFromFile("mousepic.png");
//	player.setTexture(&playerTexture);
//
//	sf::CircleShape ball(15.0f);
//	ball.setPosition(100.0f, 100.0f);
//	ball.setFillColor(sf::Color::Blue);
//
//	double xval = 0.2;
//	double yval = 0.2;
//
//	std::vector<sf::RectangleShape> rectangles;
//	int NumberInLayer = 3;
//	int NumberOfRows = 4;
//	double WidthOfBLock = 1000 / NumberInLayer;
//	double HeightOfBlock = 70;
//	double SingleoutlineWidth = 4;
//	int iter = 0;
//	for (int i = 0; i < NumberInLayer; ++i) {
//		for (int j = 0; j < NumberOfRows; ++j) {
//			rectangles.emplace_back(sf::Vector2f(WidthOfBLock - 2 * SingleoutlineWidth, HeightOfBlock - 2 * SingleoutlineWidth));
//			rectangles[iter].setFillColor(sf::Color::Yellow);
//			rectangles[iter].setOutlineColor(sf::Color::Black);
//			rectangles[iter].setOutlineThickness(SingleoutlineWidth);
//			rectangles.back().setOrigin(WidthOfBLock / 2, HeightOfBlock / 2);
//			rectangles.back().setPosition(i * WidthOfBLock + WidthOfBLock / 2, j * HeightOfBlock + HeightOfBlock / 2);
//			iter += 1;
//		}
//	}
//
//
//	while (window.isOpen())
//	{
//		sf::Event evnt;
//		while (window.pollEvent(evnt))
//		{
//			switch (evnt.type)
//			{
//			case sf::Event::Closed:
//				window.close();
//				break;
//			case sf::Event::Resized:
//				//std::cout << "New window width:" << evnt.size.width << ", New window height: " << evnt.size.height << "\n";
//				printf("New window width: %i, and new window height: %i\n", evnt.size.width, evnt.size.height);
//				break;
//			case sf::Event::TextEntered:
//				if (evnt.text.unicode < 128) {
//					printf("%c", evnt.text.unicode);
//				}
//			}
//
//			if (evnt.type == evnt.Closed) {
//				window.close();
//			}
//
//		}
//
//		/*if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::A))
//		{
//			player.move(-0.1f, 0.0f);
//		}
//		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::W))
//		{
//			player.move(0.0f, -0.1f);
//		}
//		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::S))
//		{
//			player.move(0.0f, 0.1f);
//		}
//		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Key::D))
//		{
//			player.move(0.1f, 0.0f);
//		}*/
//
//		if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
//		{
//			sf::Vector2i mousepos = sf::Mouse::getPosition(window);
//			player.setPosition((float)mousepos.x, (float)mousepos.y);
//			if (mousepos.x > 500 && mousepos.y < 200) {
//				std::cout << "HERE\n";
//				if (rectangles.size() > 5) {
//					rectangles.erase(rectangles.begin());
//				}
//			}
//		}
//
//
//		sf::Vector2f ballpos = ball.getPosition();
//		if (ballpos.x > 1000 && xval > 0)
//		{
//			xval = -0.2;
//		}
//		else if (ballpos.x < 0 && xval < 0) {
//			xval = 0.2;
//		}
//		if (ballpos.y > 700 && yval > 0) {
//			yval = -0.2;
//		}
//		else if (ballpos.y < 0 && yval < 0) {
//			yval = 0.2;
//		}
//		if (ballpos.y > 695) {
//			std::cout << "NU DU DOG!\n";
//		}
//
//		ball.setPosition(ballpos.x + xval, ballpos.y + yval);
//
//
//		window.clear();
//		window.draw(bounds);
//		window.draw(player);
//		window.draw(ball);
//		window.draw(playerbar);
//		printvector(rectangles, window);
//
//
//		/*rectangles.erase(rectangles.begin()+2);*/
//
//		//window.draw(rectangles[0]);
//		//window.draw(rectangles[1]);
//		//window.display();
//
//	}
//
//	return 0;
//}